const express=require("express");
const http=require("http");
const path=require("path");
const fs=require("fs");
const bcrypt=require("bcryptjs");
const jwt=require("jsonwebtoken");
const cookieParser=require("cookie-parser");
const multer=require("multer");
const Database=require("better-sqlite3");
const {Server}=require("socket.io");

const app=express(), server=http.createServer(app), io=new Server(server);
const PORT=process.env.PORT||3000, JWT_SECRET=process.env.JWT_SECRET||"change-this-secret";
const dataDir=process.env.DATA_DIR||path.join(__dirname,"data"), uploadDir=path.join(dataDir,"uploads");
fs.mkdirSync(dataDir,{recursive:true}); fs.mkdirSync(uploadDir,{recursive:true});

const db=new Database(path.join(dataDir,"kyli.db"));
db.pragma("journal_mode=WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
 display_name TEXT NOT NULL, bio TEXT DEFAULT '', avatar TEXT DEFAULT '', cover TEXT DEFAULT '',
 role TEXT DEFAULT 'user', theme TEXT DEFAULT '#7c3aed', emoji_bg TEXT DEFAULT '✨', status TEXT DEFAULT '',
 premium INTEGER DEFAULT 0, premium_until TEXT DEFAULT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,text TEXT DEFAULT '',image TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE IF NOT EXISTS likes(id INTEGER PRIMARY KEY AUTOINCREMENT,post_id INTEGER,user_id INTEGER,UNIQUE(post_id,user_id));
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY AUTOINCREMENT,post_id INTEGER,user_id INTEGER,text TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS friends(id INTEGER PRIMARY KEY AUTOINCREMENT,from_id INTEGER,to_id INTEGER,status TEXT DEFAULT 'pending',UNIQUE(from_id,to_id));
CREATE TABLE IF NOT EXISTS stories(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,image TEXT,text TEXT,expires_at TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS channels(id INTEGER PRIMARY KEY AUTOINCREMENT,owner_id INTEGER,name TEXT,description TEXT DEFAULT '',avatar TEXT DEFAULT '',max_subscribers INTEGER DEFAULT 1000,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS channel_members(id INTEGER PRIMARY KEY AUTOINCREMENT,channel_id INTEGER,user_id INTEGER,UNIQUE(channel_id,user_id));
CREATE TABLE IF NOT EXISTS conversations(id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS conversation_members(id INTEGER PRIMARY KEY AUTOINCREMENT,conversation_id INTEGER,user_id INTEGER,UNIQUE(conversation_id,user_id));
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,conversation_id INTEGER,user_id INTEGER,text TEXT DEFAULT '',image TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,type TEXT,text TEXT,read INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);

// Safe migrations for databases created by older Kyli versions.
for(const stmt of [
  "ALTER TABLE users ADD COLUMN status TEXT DEFAULT ''",
  "ALTER TABLE users ADD COLUMN premium INTEGER DEFAULT 0",
  "ALTER TABLE users ADD COLUMN premium_until TEXT DEFAULT NULL"
]){try{db.exec(stmt)}catch(e){if(!String(e.message).includes("duplicate column name"))throw e}}

const upload=multer({storage:multer.diskStorage({
 destination:(_,__,cb)=>cb(null,uploadDir),
 filename:(_,file,cb)=>cb(null,Date.now()+"-"+Math.random().toString(36).slice(2)+path.extname(file.originalname))
}),limits:{fileSize:20*1024*1024}});

app.use(express.json({limit:"3mb"})); app.use(express.urlencoded({extended:true})); app.use(cookieParser());
app.use("/uploads",express.static(uploadDir)); app.use(express.static(path.join(__dirname,"public")));

function premiumActive(u){
 if(!u||!u.premium)return false;
 if(!u.premium_until)return true;
 if(new Date(u.premium_until).getTime()<=Date.now()){
  db.prepare("UPDATE users SET premium=0,premium_until=NULL WHERE id=?").run(u.id); return false;
 }
 return true;
}
function tokenFor(u){return jwt.sign({id:u.id},JWT_SECRET,{expiresIn:"30d"});}
function auth(req,res,next){try{const t=req.cookies.kyli||req.headers.authorization?.replace("Bearer ",""); req.user=jwt.verify(t,JWT_SECRET); next()}catch{return res.status(401).json({error:"Необходим вход"})}}
function admin(req,res,next){if(req.user.role==="admin")return next(); const u=db.prepare("SELECT role FROM users WHERE id=?").get(req.user.id); if(u?.role==="admin"){req.user.role="admin";return next()} return res.status(403).json({error:"Только администратор"});}
function user(id){const u=db.prepare("SELECT id,username,display_name,bio,avatar,cover,role,theme,emoji_bg,status,premium,premium_until,created_at FROM users WHERE id=?").get(id); if(u)u.premium=Number(premiumActive(u)); return u}
function notify(uid,type,text){db.prepare("INSERT INTO notifications(user_id,type,text) VALUES(?,?,?)").run(uid,type,text); io.to("user:"+uid).emit("notification",{type,text});}
function isPremium(id){return premiumActive(db.prepare("SELECT * FROM users WHERE id=?").get(id));}

app.post("/api/register",async(req,res)=>{
 const {username,password,display_name}=req.body;
 if(!username||!password||!display_name)return res.status(400).json({error:"Заполни все поля"});
 if(password.length<6)return res.status(400).json({error:"Пароль минимум 6 символов"});
 try{
  const hash=await bcrypt.hash(password,10);
  const role=db.prepare("SELECT COUNT(*) c FROM users").get().c===0?"admin":"user";
  const r=db.prepare("INSERT INTO users(username,password,display_name,role) VALUES(?,?,?,?)").run(username.trim(),hash,display_name.trim(),role);
  const u=user(r.lastInsertRowid); res.cookie("kyli",tokenFor(u),{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production"}).json({user:u});
 }catch(e){res.status(400).json({error:"Такой логин уже существует"});}
});
app.post("/api/login",async(req,res)=>{
 const u=db.prepare("SELECT * FROM users WHERE username=?").get(req.body.username||"");
 if(!u||!(await bcrypt.compare(req.body.password||"",u.password)))return res.status(401).json({error:"Неверный логин или пароль"});
 res.cookie("kyli",tokenFor(u),{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production"}).json({user:user(u.id)});
});
app.post("/api/logout",(req,res)=>res.clearCookie("kyli").json({ok:true}));
app.get("/api/me",auth,(req,res)=>res.json({user:user(req.user.id)}));
app.get("/api/premium",auth,(req,res)=>{const u=user(req.user.id);res.json({active:!!u.premium,until:u.premium_until,benefits:["Премиум-бейдж рядом с именем","Расширенное оформление профиля","Увеличенные лимиты медиа до 20 МБ","Премиум-статус и дополнительные настройки"]})});

app.get("/api/feed",auth,(req,res)=>{
 const posts=db.prepare(`SELECT p.*,u.username,u.display_name,u.avatar,u.role,u.premium,
 (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) likes,
 (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) comments,
 EXISTS(SELECT 1 FROM likes l2 WHERE l2.post_id=p.id AND l2.user_id=?) liked
 FROM posts p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 100`).all(req.user.id);
 posts.forEach(p=>p.premium=Number(p.premium&&premiumActive(db.prepare("SELECT * FROM users WHERE id=?").get(p.user_id))));
 res.json({posts});
});
app.post("/api/posts",auth,upload.single("image"),(req,res)=>{
 const text=String(req.body.text||"").trim();
 if(text.length>5000)return res.status(400).json({error:"Пост слишком длинный (максимум 5000 символов)"});
 const image=req.file?"/uploads/"+req.file.filename:"";
 const r=db.prepare("INSERT INTO posts(user_id,text,image) VALUES(?,?,?)").run(req.user.id,text,image);
 res.json({id:r.lastInsertRowid});
});
app.post("/api/posts/:id/like",auth,(req,res)=>{
 const p=db.prepare("SELECT user_id FROM posts WHERE id=?").get(req.params.id); if(!p)return res.sendStatus(404);
 const exists=db.prepare("SELECT id FROM likes WHERE post_id=? AND user_id=?").get(req.params.id,req.user.id);
 if(exists)db.prepare("DELETE FROM likes WHERE id=?").run(exists.id); else {db.prepare("INSERT INTO likes(post_id,user_id) VALUES(?,?)").run(req.params.id,req.user.id); if(p.user_id!==req.user.id)notify(p.user_id,"like",`${user(req.user.id).display_name} поставил(а) лайк вашему посту`)}
 res.json({liked:!exists});
});
app.post("/api/posts/:id/comments",auth,(req,res)=>{
 if(!req.body.text?.trim())return res.status(400).json({error:"Пустой комментарий"});
 const p=db.prepare("SELECT user_id FROM posts WHERE id=?").get(req.params.id);
 db.prepare("INSERT INTO comments(post_id,user_id,text) VALUES(?,?,?)").run(req.params.id,req.user.id,req.body.text.trim());
 if(p&&p.user_id!==req.user.id)notify(p.user_id,"comment",`${user(req.user.id).display_name} прокомментировал(а) ваш пост`);
 res.json({ok:true});
});
app.get("/api/posts/:id/comments",auth,(req,res)=>res.json({comments:db.prepare(`SELECT c.*,u.display_name,u.avatar,u.premium FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=? ORDER BY c.id`).all(req.params.id)}));

app.get("/api/users",auth,(req,res)=>{
 const q="%"+(req.query.q||"").replace(/[%_]/g,"")+"%";
 const users=db.prepare("SELECT id,username,display_name,bio,avatar,role,status,premium FROM users WHERE id<>? AND (username LIKE ? OR display_name LIKE ?) ORDER BY id DESC LIMIT 50").all(req.user.id,q,q);
 users.forEach(u=>u.premium=Number(u.premium&&premiumActive(db.prepare("SELECT * FROM users WHERE id=?").get(u.id))));
 res.json({users});
});
app.post("/api/friends/:id",auth,(req,res)=>{
 const to=Number(req.params.id); if(to===req.user.id)return res.status(400).json({error:"Нельзя добавить себя"});
 const old=db.prepare("SELECT * FROM friends WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?)").get(req.user.id,to,to,req.user.id);
 if(old)return res.json(old);
 db.prepare("INSERT INTO friends(from_id,to_id,status) VALUES(?,?,?)").run(req.user.id,to,"pending");
 notify(to,"friend",`${user(req.user.id).display_name} отправил(а) вам заявку в друзья`); res.json({status:"pending"});
});
app.get("/api/friends",auth,(req,res)=>res.json({friends:db.prepare(`SELECT f.*,u.id uid,u.display_name,u.username,u.avatar,u.premium,u.status FROM friends f JOIN users u ON u.id=CASE WHEN f.from_id=? THEN f.to_id ELSE f.from_id END WHERE f.from_id=? OR f.to_id=?`).all(req.user.id,req.user.id,req.user.id)}));
app.post("/api/friends/:id/accept",auth,(req,res)=>{db.prepare("UPDATE friends SET status='accepted' WHERE id=? AND to_id=?").run(req.params.id,req.user.id);res.json({ok:true})});

app.get("/api/stories",auth,(req,res)=>{
 const stories=db.prepare(`SELECT s.*,u.display_name,u.avatar,u.premium FROM stories s JOIN users u ON u.id=s.user_id WHERE datetime(s.expires_at)>datetime('now') ORDER BY s.id DESC`).all();
 stories.forEach(s=>s.premium=Number(s.premium&&premiumActive(db.prepare("SELECT * FROM users WHERE id=?").get(s.user_id)))); res.json({stories});
});
app.post("/api/stories",auth,upload.single("image"),(req,res)=>{
 if(!req.file)return res.status(400).json({error:"Нужно изображение"});
 const image="/uploads/"+req.file.filename;
 db.prepare("INSERT INTO stories(user_id,image,text,expires_at) VALUES(?,?,?,datetime('now','+1 day'))").run(req.user.id,image,String(req.body.text||"").slice(0,1000)); res.json({ok:true});
});

app.get("/api/channels",auth,(req,res)=>res.json({channels:db.prepare(`SELECT c.*,u.display_name owner_name,u.avatar owner_avatar,(SELECT COUNT(*) FROM channel_members m WHERE m.channel_id=c.id) subscribers,EXISTS(SELECT 1 FROM channel_members m2 WHERE m2.channel_id=c.id AND m2.user_id=?) joined FROM channels c JOIN users u ON u.id=c.owner_id ORDER BY c.id DESC`).all(req.user.id)}));
app.post("/api/channels",auth,(req,res)=>{
 const {name,description,max_subscribers}=req.body;
 if(!name)return res.status(400).json({error:"Название обязательно"});
 const max=Math.max(1,Number(max_subscribers)||1000);
 const r=db.prepare("INSERT INTO channels(owner_id,name,description,max_subscribers) VALUES(?,?,?,?)").run(req.user.id,String(name).trim().slice(0,80),String(description||"").slice(0,500),max);
 db.prepare("INSERT INTO channel_members(channel_id,user_id) VALUES(?,?)").run(r.lastInsertRowid,req.user.id); res.json({id:r.lastInsertRowid});
});
app.post("/api/channels/:id/join",auth,(req,res)=>{
 const c=db.prepare("SELECT * FROM channels WHERE id=?").get(req.params.id); if(!c)return res.sendStatus(404);
 const n=db.prepare("SELECT COUNT(*) c FROM channel_members WHERE channel_id=?").get(c.id).c;
 const member=db.prepare("SELECT id FROM channel_members WHERE channel_id=? AND user_id=?").get(c.id,req.user.id);
 if(member){db.prepare("DELETE FROM channel_members WHERE id=?").run(member.id);return res.json({joined:false})}
 if(n>=c.max_subscribers)return res.status(409).json({error:"Лимит подписчиков достигнут"});
 db.prepare("INSERT INTO channel_members(channel_id,user_id) VALUES(?,?)").run(c.id,req.user.id); res.json({joined:true});
});

app.put("/api/profile",auth,upload.fields([{name:"avatar",maxCount:1},{name:"cover",maxCount:1}]),(req,res)=>{
 const fields=req.body, sets=[], vals=[];
 for(const k of ["display_name","bio","theme","emoji_bg","status"]){if(fields[k]!==undefined){if(k==="bio"&&String(fields[k]).length>1000&&!isPremium(req.user.id))return res.status(400).json({error:"Длинное описание доступно Premium"});sets.push(k+"=?");vals.push(String(fields[k]).slice(0,k==="bio"?5000:500))}}
 if(req.files?.avatar){sets.push("avatar=?");vals.push("/uploads/"+req.files.avatar[0].filename)}
 if(req.files?.cover){sets.push("cover=?");vals.push("/uploads/"+req.files.cover[0].filename)}
 if(sets.length)db.prepare("UPDATE users SET "+sets.join(",")+" WHERE id=?").run(...vals,req.user.id);
 res.json({user:user(req.user.id)});
});
app.get("/api/profile/:id",auth,(req,res)=>{const u=user(req.params.id); if(!u)return res.sendStatus(404); res.json({user:u,posts:db.prepare("SELECT p.*, (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) likes, (SELECT COUNT(*) FROM comments c WHERE c.post_id=p.id) comments FROM posts p WHERE user_id=? ORDER BY id DESC").all(u.id)})});

app.get("/api/conversations",auth,(req,res)=>{
 const cs=db.prepare(`SELECT c.id,c.created_at,(SELECT GROUP_CONCAT(u.display_name, ', ') FROM conversation_members cm JOIN users u ON u.id=cm.user_id WHERE cm.conversation_id=c.id AND u.id<>?) names,(SELECT text FROM messages m WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) last_message FROM conversations c JOIN conversation_members mine ON mine.conversation_id=c.id AND mine.user_id=? ORDER BY c.id DESC`).all(req.user.id,req.user.id);
 res.json({conversations:cs});
});
app.post("/api/conversations",auth,(req,res)=>{
 const other=Number(req.body.user_id); if(!other||other===req.user.id)return res.status(400).json({error:"Пользователь не найден"});
 let c=db.prepare(`SELECT c.id FROM conversations c JOIN conversation_members a ON a.conversation_id=c.id AND a.user_id=? JOIN conversation_members b ON b.conversation_id=c.id AND b.user_id=? WHERE (SELECT COUNT(*) FROM conversation_members x WHERE x.conversation_id=c.id)=2`).get(req.user.id,other);
 if(!c){const r=db.prepare("INSERT INTO conversations DEFAULT VALUES").run(); c={id:r.lastInsertRowid}; db.prepare("INSERT INTO conversation_members(conversation_id,user_id) VALUES(?,?),(?,?)").run(c.id,req.user.id,c.id,other)}
 res.json(c);
});
app.get("/api/conversations/:id/messages",auth,(req,res)=>{
 const ok=db.prepare("SELECT id FROM conversation_members WHERE conversation_id=? AND user_id=?").get(req.params.id,req.user.id); if(!ok)return res.sendStatus(403);
 res.json({messages:db.prepare("SELECT m.*,u.display_name,u.avatar,u.premium FROM messages m JOIN users u ON u.id=m.user_id WHERE conversation_id=? ORDER BY m.id").all(req.params.id)});
});
app.post("/api/conversations/:id/messages",auth,(req,res)=>{
 const ok=db.prepare("SELECT id FROM conversation_members WHERE conversation_id=? AND user_id=?").get(req.params.id,req.user.id); if(!ok)return res.sendStatus(403);
 const text=String(req.body.text||"").trim(); if(!text)return res.status(400).json({error:"Пустое сообщение"});
 const r=db.prepare("INSERT INTO messages(conversation_id,user_id,text) VALUES(?,?,?)").run(req.params.id,req.user.id,text.slice(0,4000));
 const msg=db.prepare("SELECT m.*,u.display_name,u.avatar,u.premium FROM messages m JOIN users u ON u.id=m.user_id WHERE m.id=?").get(r.lastInsertRowid);
 io.to("conv:"+req.params.id).emit("message",msg); res.json(msg);
});

app.get("/api/notifications",auth,(req,res)=>res.json({notifications:db.prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50").all(req.user.id)}));

app.get("/api/admin/stats",auth,admin,(req,res)=>res.json({users:db.prepare("SELECT COUNT(*) c FROM users").get().c,posts:db.prepare("SELECT COUNT(*) c FROM posts").get().c,channels:db.prepare("SELECT COUNT(*) c FROM channels").get().c,stories:db.prepare("SELECT COUNT(*) c FROM stories").get().c,premium:db.prepare("SELECT COUNT(*) c FROM users WHERE premium=1").get().c}));
app.get("/api/admin/users",auth,admin,(req,res)=>{const users=db.prepare("SELECT id,username,display_name,role,created_at,premium,premium_until,status FROM users ORDER BY id DESC LIMIT 500").all();users.forEach(u=>u.premium=Number(u.premium&&premiumActive(db.prepare("SELECT * FROM users WHERE id=?").get(u.id))));res.json({users})});
app.put("/api/admin/users/:id",auth,admin,(req,res)=>{const role=req.body.role==="admin"?"admin":"user";db.prepare("UPDATE users SET role=? WHERE id=?").run(role,req.params.id);res.json({ok:true})});
app.delete("/api/admin/users/:id",auth,admin,(req,res)=>{if(Number(req.params.id)===req.user.id)return res.status(400).json({error:"Нельзя удалить себя"});db.prepare("DELETE FROM users WHERE id=?").run(req.params.id);res.json({ok:true})});
app.put("/api/admin/users/:id/premium",auth,admin,(req,res)=>{
 const id=Number(req.params.id); const mode=String(req.body.mode||"days");
 if(!db.prepare("SELECT id FROM users WHERE id=?").get(id))return res.sendStatus(404);
 if(mode==="off"){db.prepare("UPDATE users SET premium=0,premium_until=NULL WHERE id=?").run(id);notify(id,"premium","Premium отключён администратором");return res.json({ok:true,active:false})}
 if(mode==="lifetime"){db.prepare("UPDATE users SET premium=1,premium_until=NULL WHERE id=?").run(id);notify(id,"premium","🎉 Вам выдан Premium навсегда!");return res.json({ok:true,active:true,until:null})}
 const days=Math.max(1,Math.min(3650,Number(req.body.days)||30));
 db.prepare("UPDATE users SET premium=1,premium_until=datetime('now',?) WHERE id=?").run(`+${days} days`,id);
 const u=user(id); notify(id,"premium",`🎉 Вам выдан Premium на ${days} дн.`); res.json({ok:true,active:true,until:u.premium_until});
});
app.put("/api/admin/channels/:id",auth,admin,(req,res)=>{db.prepare("UPDATE channels SET max_subscribers=? WHERE id=?").run(Math.max(1,Number(req.body.max_subscribers)||1),req.params.id);res.json({ok:true})});
app.delete("/api/admin/posts/:id",auth,admin,(req,res)=>{db.prepare("DELETE FROM posts WHERE id=?").run(req.params.id);res.json({ok:true})});

io.on("connection",socket=>{
 socket.on("auth",({userId})=>socket.join("user:"+userId));
 socket.on("joinConversation",id=>socket.join("conv:"+id));
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
const HOST=process.env.HOST||"0.0.0.0";
server.listen(PORT,HOST,()=>console.log(`Kyli running on http://${HOST}:${PORT}`));
